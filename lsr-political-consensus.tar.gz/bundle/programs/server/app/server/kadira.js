(function(){Kadira.connect('JKLKr7R6JRpnm3Shp', '84fef28c-0bd5-44e2-9b6c-c2eb3ab599c1');
}).call(this);
